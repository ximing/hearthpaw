import Foundation
import Darwin

struct AppSettings: Codable, Equatable, Sendable {
    var petSize: Double
    var companionModelID: String
    var researchModelID: String

    init(petSize: Double = 160, companionModelID: String = "", researchModelID: String = "") {
        self.petSize = petSize
        self.companionModelID = companionModelID
        self.researchModelID = researchModelID
    }

    // The secret is deliberately not part of this value or its serialized schema.
    private enum CodingKeys: String, CodingKey {
        case petSize, companionModelID, researchModelID
    }

    func validated() throws -> AppSettings {
        guard petSize.isFinite, (100...220).contains(petSize) else {
            throw SettingsValidationError.invalidPetSize
        }
        return try AppSettings(
            petSize: petSize,
            companionModelID: Self.validatedModelID(companionModelID, field: "陪伴模型"),
            researchModelID: Self.validatedModelID(researchModelID, field: "调研模型")
        )
    }

    private static func validatedModelID(_ value: String, field: String) throws -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "" }
        // OpenRouter-style provider/model IDs, with an optional variant such as :free.
        // This is syntax checking only, not a catalog, pricing or capability check.
        let pattern = #"\A[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*(?::[A-Za-z0-9][A-Za-z0-9._-]*)?\z"#
        guard trimmed.range(of: pattern, options: .regularExpression) != nil else {
            throw SettingsValidationError.invalidModelID(field: field)
        }
        return trimmed
    }
}

enum SettingsValidationError: LocalizedError {
    case invalidPetSize
    case invalidModelID(field: String)

    var errorDescription: String? {
        switch self {
        case .invalidPetSize:
            return "宠物尺寸必须是 100 至 220 之间的有限数值。"
        case .invalidModelID(let field):
            return "\(field) ID 格式应为 provider/model（可带 :free 等后缀），不能是网址或包含内部空白。"
        }
    }
}

final class AppSettingsStore {
    let fileURL: URL
    private let lock = NSLock()

    static var defaultFileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("TuanTuan", isDirectory: true)
            .appendingPathComponent("settings.json", isDirectory: false)
    }

    init(fileURL: URL = AppSettingsStore.defaultFileURL) {
        self.fileURL = fileURL
    }

    func load() throws -> AppSettings {
        lock.lock()
        defer { lock.unlock() }
        let data: Data
        do {
            data = try Data(contentsOf: fileURL)
        } catch {
            // Do not treat permission errors, directories or corrupt data as missing settings.
            let cocoaError = error as NSError
            if cocoaError.domain == NSCocoaErrorDomain,
               cocoaError.code == NSFileReadNoSuchFileError {
                return AppSettings()
            }
            throw error
        }
        return try JSONDecoder().decode(AppSettings.self, from: data).validated()
    }

    func save(_ settings: AppSettings) throws {
        // Validate and encode before touching either the directory or the old file.
        let validated = try settings.validated()
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        var data = try encoder.encode(validated)
        data.append(0x0A)

        lock.lock()
        defer { lock.unlock() }
        let directory = fileURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        let temporaryURL = directory.appendingPathComponent(".settings-\(UUID().uuidString).tmp")
        // Exclusive creation gives the staging file its safe permissions before any bytes are written.
        let descriptor = temporaryURL.path.withCString {
            Darwin.open($0, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, mode_t(0o600))
        }
        guard descriptor >= 0 else { throw Self.posixError() }
        let handle = FileHandle(fileDescriptor: descriptor, closeOnDealloc: true)
        defer { try? FileManager.default.removeItem(at: temporaryURL) }
        do {
            try handle.write(contentsOf: data)
            try handle.synchronize()
            try handle.close()
        } catch {
            try? handle.close()
            throw error
        }
        // rename is atomic on this same-directory filesystem path. The old file remains on failure.
        // No fallible operation follows the commit, so an error never reports a committed write.
        let status = temporaryURL.path.withCString { source in
            fileURL.path.withCString { destination in Darwin.rename(source, destination) }
        }
        guard status == 0 else { throw Self.posixError() }
    }

    private static func posixError() -> NSError {
        NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
    }
}
