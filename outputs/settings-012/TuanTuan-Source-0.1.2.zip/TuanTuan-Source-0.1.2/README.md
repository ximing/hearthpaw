# 团团：macOS 治愈萌宠 Agent

原生 Swift/AppKit 低资源桌面宠物，当前迭代 **0.1.2：分区触摸 + 自定义模型设置**。完整目标见 [MVP 设计](docs/mvp-design.md)，术语见 [GLOSSARY](GLOSSARY.md)。聊天、记忆与调研 Agent 尚未接入，不将配置能力冒充模型调用。

## 运行与操作

```sh
open outputs/phase1/TuanTuan.app
# 首次启动并直接显示设置：
open outputs/phase1/TuanTuan.app --args --settings
```

需 Apple Silicon、macOS 15+。这是本机 ad-hoc 签名原型，未做 Developer ID 公证，不是公开分发版本。换电脑后若有系统安全提示，不建议绕过安全检查，应配置正式签名与公证。重新签名升级可能触发钥匙串访问重新授权，失败时不明文回退。

单击头顶局部点头，脸颊轻蹭/脸红，肚子软弹，尾巴局部摆动。拖动换位置、右键菜单管理；菜单栏“试试分区反馈”分别演示。透明像素不触发，拖动不误触抚摸，静置不循环动画。菜单“回到主屏右下角”找回角色；隐藏保留进程，退出结束应用。不常驻 Dock。

## 设置：外观与模型

通过菜单栏或右键 → **设置：外观与模型…** 打开。

外观页保留 100–220 pt 尺寸调整，保存尺寸后重启恢复；位置仍在本次运行中保留，重启默认右下角。

模型页固定使用 OpenRouter，分别输入**陪伴模型 ID**和**调研模型 ID**，可用同一模型。输入模型 ID，不是显示名称、URL 或 API key。保存是本机格式校验与持久化，不代表模型存在或支持结构化路由/调研工具；不会联网拉取模型目录，也不会自动产生模型费用。

**密钥单独管理**：在安全输入框粘贴自己的 OpenRouter API key，点击保存密钥，存入本机非同步 Keychain。界面只显示状态、不回填密钥；输入留空不删除，删除使用独立按钮。恢复模型默认不会删除密钥。不要把真实密钥放入源码、Markdown、测试数据或发到对话里。

普通设置位于当前用户 `~/Library/Application Support/TuanTuan/settings.json`，只有尺寸和两个模型 ID，不包含 API key。损坏配置会提示，不自动覆盖；须明确恢复默认后再保存。设置页关闭不退出团团，修改未保存前不冒充已生效。

## 当前边界

一个原创透明 PNG 通过头、身、尾裁切图层做短动作，不是完整骨骼、Live2D、逐帧重绘或新表情素材。动作结束有一次可取消清理，没有持续帧循环。还没有声音、主动招呼调度、亲密度计分、聊天、模型请求、角色 system prompt 编辑、长期记忆、二级路由或调研执行。

透明区域穿透依靠 alpha mask 和鼠标移动事件，不设持续轮询；不监听按键、不记录指针历史、不读取用户屏幕、私人文件、剪贴板或麦克风。持久化只读写应用自己的设置，密钥只管理指定的钥匙串项目。[第一阶段实现说明](docs/phase1-implementation.md) 记录窗口与动画细节。

## 构建与测试

本机使用 Xcode 26.1.1、Swift 6.2.1、XcodeGen 2.46.0，无第三方运行时依赖。

```sh
./build-phase1.sh
```

`project.yml` 是配置源，`TuanTuan.xcodeproj` 由 XcodeGen 生成；源码位于 `Sources/TuanTuan`，素材位于 `Resources`。缓存与验证位于 `.work`；最新构建仍写入 `outputs/phase1/TuanTuan.app`，分版本交付说明见 `outputs` 对应目录。

`Package.swift` 只承载非图形测试，不用于构建桌面应用：

```sh
swift test --scratch-path .work/settings-012/swift-tests \
  --cache-path .work/settings-012/swift-cache \
  --config-path .work/settings-012/swift-config \
  --security-path .work/settings-012/swift-security
```

应用内部图形和动画验证：

```sh
outputs/phase1/TuanTuan.app/Contents/MacOS/TuanTuan \
  --validate-at "$PWD/.work/settings-012/validation/manual"
```

内部验证仅操作本应用，设置使用隔离配置和内存密钥适配器，不修改用户真实模型设置或钥匙串，不读取整个桌面或控制其他应用。它不等于真人跨应用点击、全屏和物理多屏端到端验收。Keychain 系统级隔离验证另行记录，不用真实用户 key 测试。
