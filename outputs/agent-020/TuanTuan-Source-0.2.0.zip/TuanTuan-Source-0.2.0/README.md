# 团团：macOS 治愈萌宠 Agent

原生 Swift/AppKit 低资源桌面宠物。当前迭代 **0.2.0：陪伴聊天、独立调研与自定义人格**。完整目标见 [MVP 设计](docs/mvp-design.md)，术语见 [GLOSSARY](GLOSSARY.md)。长期记忆、养成计分和本地主动招呼仍未实现，不把当前版本冒充完整 MVP。

## 启动和桌面互动

```sh
open outputs/phase1/TuanTuan.app --args --chat
```

菜单栏爪印 / 宠物右键 → **和团团聊天 / 调研报告…** 打开原生聊天窗口。窗口关闭不退出宠物，也不自动取消独立调研；请使用明确的取消按钮。宠物头顶点头、脸颊轻蹭和脸红、肚子软弹、尾巴局部摆动；拖动不误触，透明处穿透，静置无持续动画。无 Dock 常驻图标。

## 配置模型与角色

菜单 → 设置，在模型页填入自己的 OpenRouter key 并单独保存；陪伴、调研各填一个完整 `provider/model-id`，可以同用一个。两个模型都需要支持相应工具调用 / Responses API。应用不会自动选模型、改模型或换付费工具路线。

角色页可以自定义身份、角色和语气，保存后从下一次陪伴请求生效；纯本地预览不调用模型。角色设定不改变执行权限，正在运行的工作任务保留自己的独立专业指令。外观页的 100–220 pt 尺寸、模型与人格都持久化，旧版配置缺少人格字段时使用默认团团模板。

Keychain 中的密钥不回填，清空输入不删除，单独按钮删除；模型恢复默认不删除密钥。普通配置位于 `~/Library/Application Support/TuanTuan/settings.json`，不含 API key。设置损坏时提示而不静默覆盖。

## 聊天和调研

**发送**调用配置的陪伴模型并流式显示。清晰的工作指令可以让陪伴模型提出 `delegate_research` 路由，本地只接受登记工具、确切当前委派语句和受支持范围；含糊请求先澄清，非法或重复工具动作不执行。也可直接点击 **调研并生成报告**，明确提交本次输入作为工作任务。

调研仅接收当前提交的任务，不带私人聊天、完整历史或宠物人格。服务器端固定使用 Exa 搜索与 OpenRouter 正文获取，最多 3 次搜索、5 篇正文；整个工作任务至多 2 次客户端模型请求、5 分钟，低于设计的 3 次请求上限。第二次请求没有网页工具，只依据第一次真实读取的正文写标准简报。模型正文自报来源不算读取证据，引用越界、缺少正文或超限不标记完成。

**调用会产生模型 token 费用，调研还可能产生搜索工具费用。** 次数不是美元硬上限，OpenRouter 远端内部可能有多次模型处理；实际费用见账户。应用没有后台自动调用、失败重试、自动续费重跑或模型替换。普通聊天本身不联网查资料，不应把模型知识回答当作最新事实核验。

最多一个调研工作任务，期间可以继续陪聊；额外工作请求显示忙碌，不自动排队。可以分别取消回复和调研；断开连接不保证所有供应商立刻停止生成和计费。锁屏、休眠和退出会请求取消，恢复或重启不自动重跑。

报告在 `~/Library/Application Support/TuanTuan/Tasks/<UUID>/report.md`，任务元信息持久化；失败时尽可能保留 `draft.md`。确认文件与元信息写入成功才显示完成。界面提供历史任务、打开、Finder显示和另存为，不让模型指定任意写入路径，也不静默覆盖已有用户文件。

## 数据边界

聊天只在本次运行中保留，退出清除。模型上下文最多最近 20 条、6,000 字符；当前输入过长会提示缩短，不静默丢弃。角色设定上限 6,000 字符。失败回复片段可见但不当作成功历史传入后续请求。

发送会将当前输入、受限聊天上下文及角色设定交给 OpenRouter / 所选模型供应商；调研主题和公开来源还会被工具后端处理。`store:false` 不等于保证供应商或搜索后端零留存，应结合各自账户隐私设置。API key 仅在用户主动发起请求时从本机非同步登录 Keychain 读取，仅发到固定官方 HTTPS 地址，不进入 prompt、普通 JSON、任务元信息或日志，不跟随跨域重定向。

没有任意 shell、私人文件遍历、屏幕读取、剪贴板、麦克风、浏览器账户操作或外部发布权限。报告和网页正文作为不可信资料，不作为新的执行指令。当前没有长期记忆读写、自动养成计分或后台问候模型。

## 构建与验证

需 Apple Silicon、macOS 15+，使用本机 Xcode、Swift6 和 XcodeGen，无第三方运行时依赖。当前是 ad-hoc 本机签名，未做 Developer ID 公证；重新签名或换电脑可能需要系统重新授权钥匙串，失败不会明文回退。

```sh
./build-phase1.sh
swift test --scratch-path .work/ai-020/swift-tests \
  --cache-path .work/ai-020/swift-cache \
  --config-path .work/ai-020/swift-config \
  --security-path .work/ai-020/swift-security
```

`project.yml` 为 XcodeGen 源，原生应用输出仍为 `outputs/phase1/TuanTuan.app`；分版本交付另存于 `outputs`。纯逻辑 SwiftPM 不构建 AppKit 窗口。

```sh
# 旧宠物窗口 / 设置 / 动画回归（独立scratch设置、内存key）
outputs/phase1/TuanTuan.app/Contents/MacOS/TuanTuan \
  --validate-at "$PWD/.work/ai-020/validation/appkit"
# 聊天 → 路由 → 调研 → 真实报告文件 → 原生聊天窗口（合成模型）
outputs/phase1/TuanTuan.app/Contents/MacOS/TuanTuan \
  --validate-agent-at "$PWD/.work/ai-020/validation/agent"
```

开发验证不使用生产密钥，不发起付费模型请求。模拟协议、调研与本机文件链路的通过，不代表用户实际账号 / 所选模型已经联网验证。真实 API 兼容性由用户主动发送时确认；失败保留输入/片段，显示原因且不自动重试。新版完整三十分钟资源与跨应用真人鼠标验收仍需单独测量。官方接口依据见 [接入查证](docs/research/openrouter-agent-integration.md)。
