# 团团：macOS 治愈萌宠 Agent

首版设计已通过逐轮访谈确认；当前只实现**第一阶段：无 AI 原生宠物原型**。完整实施基线见 [MVP 设计](docs/mvp-design.md)，术语见 [GLOSSARY](GLOSSARY.md)。

## 运行

在本项目中双击 `outputs/phase1/TuanTuan.app`，或执行：

```sh
open outputs/phase1/TuanTuan.app
```

需 Apple Silicon、macOS 15+。这是本机 ad-hoc 签名原型，不是已公证的公开分发版本。若搬到另一台电脑后出现系统安全提示，不建议绕过安全检查，应后续配置正式签名与公证。

菜单栏爪印用于管理团团。单击角色抚摸，拖动移动，右键打开菜单；“尺寸与说明”调整 100–220 pt；“回到主屏右下角”找回角色；“隐藏”保留进程，“退出”结束应用。不常驻 Dock。

## 当前边界

0.1.1 已支持四分区触摸：头顶局部点头轻弹，脸颊轻蹭和脸红，肚子身躯软弹，尾巴局部摆动。菜单栏“试试分区反馈”可分别演示。拖动不会触发抚摸，透明区域不触发，100–220 pt 缩放下保持同一分区规则。

当前仍只用一个原创姿态，将现有像素裁切为头、身、尾图层并以短时间变换组合，不是完整骨骼、Live2D、逐帧重绘或新表情素材。没有声音、主动招呼调度、亲密度计分、联网、OpenRouter、角色 prompt 编辑、长期记忆或真实工作 Agent；这些将在后续阶段增加。短文字反馈为本地文案，不是模型回复。尺寸和位置当前只保存在内存中，重启恢复默认。

透明像素的鼠标穿透使用 alpha mask 和鼠标移动事件，不设持续轮询；不监听按键、不记录指针历史、不读取用户屏幕、私人文件、剪贴板或麦克风。实现及官方依据见 [第一阶段实现说明](docs/phase1-implementation.md)。

## 构建

使用已有的 Xcode 26.1.1 和 XcodeGen 2.46.0，无第三方运行时依赖。

```sh
./build-phase1.sh
```

`project.yml` 是工程配置源，`TuanTuan.xcodeproj` 由 XcodeGen 生成。`Sources/TuanTuan` 包含原生应用，`Resources` 包含运行素材，`Tests/TuanTuanTests` 包含几何与 alpha 测试。构建缓存和验证材料位于 `.work/phase1`，用户交付文件位于 `outputs/phase1`。

`Package.swift` 只为纯几何/alpha 测试提供无图形宿主入口，不用于构建桌面应用：

```sh
swift test --scratch-path .work/phase1/swift-tests \
  --cache-path .work/phase1/swift-cache \
  --config-path .work/phase1/swift-config \
  --security-path .work/phase1/swift-security
```

## 应用内部验证

```sh
outputs/phase1/TuanTuan.app/Contents/MacOS/TuanTuan \
  --validate-at "$PWD/.work/phase1/validation/manual-appkit"
```

它只操作本应用，导出自身视图和检查 JSON 后退出，不读取整个桌面或控制其他应用。内部检查不等于真人跨应用鼠标点击、全屏切换和物理多屏端到端验收。
