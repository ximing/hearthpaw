// swift-tools-version: 6.0
import PackageDescription

// Pure geometry/alpha QA only. The actual macOS app is built from project.yml.
let package = Package(
    name: "TuanTuanGeometryQA",
    platforms: [.macOS(.v15)],
    products: [.library(name: "TuanTuanGeometryQA", targets: ["TuanTuan"])],
    targets: [
        .target(
            name: "TuanTuan",
            path: "Sources/TuanTuan",
            exclude: ["AppDelegate.swift", "PetView.swift", "PetWindowController.swift", "main.swift"],
            sources: ["PetGeometry.swift"]
        ),
        .testTarget(name: "TuanTuanTests", dependencies: ["TuanTuan"], path: "Tests/TuanTuanTests")
    ]
)
